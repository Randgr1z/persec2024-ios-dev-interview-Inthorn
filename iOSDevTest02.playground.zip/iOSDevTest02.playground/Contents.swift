import Foundation

func sortChannels(_ items: [String]) -> [String] {
    
    return items.sorted {
        
        // ใช้ replacingOccurrences , .regularExpression [^0-9] เพื่อแทนที่ทุกตัวอักษรที่ไม่ใช่ตัวเลขด้วยสตริงว่าง (""), จากนั้นแปลงผลลัพธ์เป็น Int หากไม่สามารถแปลงเป็นตัวเลขได้ จะใช้ค่า 0 แทน
        
        let first = Int($0.replacingOccurrences(of: "[^0-9]", with: "", options: .regularExpression)) ?? 0
        let second = Int($1.replacingOccurrences(of: "[^0-9]", with: "", options: .regularExpression)) ?? 0
        
        return first < second
    }
}

// func test
let channels = ["TH19","SG20","TH2","TH10","TH3Netflix","TH1","TH7"]
let sortedItems = sortChannels(channels)
print(sortedItems)

