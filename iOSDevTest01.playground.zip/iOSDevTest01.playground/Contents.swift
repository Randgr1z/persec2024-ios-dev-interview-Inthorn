import UIKit

func charCheck(_ s: String ) -> Bool {
    var elements: [Character] = []
    let symbols: [Character: Character] = [")": "(","]": "[","}": "{"]
    
    for char in s {
        if let matchingSymbols = symbols[char] {
            if elements.isEmpty || elements.last != matchingSymbols {
                return false
            }
            elements.removeLast()
        } else {
            elements.append(char)
        }
    }
    return elements.isEmpty
}

// func test
print(charCheck("()"))
print(charCheck("([]]"))
print(charCheck("({[]})"))
print(charCheck("([[{}]]]"))
print(charCheck(")"))
print(charCheck("(]}])"))
print(charCheck("([)]"))
print(charCheck("}"))
