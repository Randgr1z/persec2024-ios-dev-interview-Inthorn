import Foundation

func tribonacci(_ initial: [Int], _ n: Int) -> [Int] {

    guard n >= 0 else { return [] }
    
    var result = initial
    
    if n < result.count {
        return Array(result.prefix(n))
    }
    
    for i in result.count..<n {
        let nextValue = result[i - 1] + result[i - 2] + result[i - 3]
        result.append(nextValue)
    }
    
    return result
}

// func test
print(tribonacci([1, 3, 5], 5))
print(tribonacci([2, 2, 2], 3))
print(tribonacci([10, 10, 10], 4))
