import Foundation

func sortDigits(_ number: Int) -> Int? {
    guard number >= 0 else { return nil }
    
    let sortedDigits = String(number)
        .compactMap { $0.wholeNumberValue }
        .sorted(by: >)
    let resultString = sortedDigits.map { String($0) }.joined()
    return Int(resultString)
}

// func test
let sortedNumber1 = sortDigits(3008)
    print(sortedNumber1!)
let sortedNumber2 = sortDigits(1989)
    print(sortedNumber2!)
let sortedNumber3 = sortDigits(2679)
    print(sortedNumber3!)
let sortedNumber4 = sortDigits(9163)
    print(sortedNumber4!)

