import Foundation

func autocomplete(search: String, items: [String], maxResult: Int) -> [String] {
    let filteredItems = items.filter { item in
        item.lowercased().contains(search.lowercased())
    }
    
    let sortedItems = filteredItems.sorted {
        let range1 = $0.lowercased().range(of: search.lowercased())!
        let range2 = $1.lowercased().range(of: search.lowercased())!
        
        if range1.lowerBound == $0.startIndex {
            return true
        } else if range2.lowerBound == $1.startIndex {
            return false
        } else {
            return range1.lowerBound < range2.lowerBound
        }
}
    return Array(sortedItems.prefix(maxResult))
}

// func test
let result = autocomplete(search: "th", items: ["Mother", "Think", "Worthy", "Apple", "Android"], maxResult: 2)
print(result)

