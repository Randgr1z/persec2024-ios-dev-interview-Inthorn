import Foundation

func convertNumber(_ input: Any) -> Any? {
    if let num = input as? Int {
        return intToRoman(num)
    } else if let roman = input as? String {
        return romanToInt(roman)
    }
    return nil
}

private func intToRoman(_ num: Int) -> String {
    let romanSymbols: [(value: Int, symbols: String)] = [
        (1000, "M"),
        (900, "CM"),
        (500, "D"),
        (400, "CD"),
        (100, "C"),
        (90, "XC"),
        (50, "L"),
        (40, "XL"),
        (10, "X"),
        (9, "IX"),
        (5, "V"),
        (4, "IV"),
        (1, "I")
    ]
    
    var number = num
    var result = ""
    
    for (value, symbols) in romanSymbols {
        while number >= value {
            result += symbols
            number -= value
        }
    }
    
    return result
}

private func romanToInt(_ s: String) -> Int {
    let romanValues: [Character: Int] = [
        "I": 1,
        "V": 5,
        "X": 10,
        "L": 50,
        "C": 100,
        "D": 500,
        "M": 1000
    ]
    
    var total = 0
    var prevValue = 0
    
    for char in s {
        let value = romanValues[char] ?? 0
        if value > prevValue {
            total += value - 2 * prevValue
        } else {
            total += value
        }
        prevValue = value
    }
    
    return total
}

// func test
let roman = convertNumber(68)
print(roman ?? "Error")

let number = convertNumber("MCMLXXXIX")
print(number ?? "Error")
